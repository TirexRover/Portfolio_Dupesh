declare const _default: import("vite").UserConfigFnObject;
export default _default;
